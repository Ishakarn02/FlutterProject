import 'package:flutter/material.dart';

import 'package:netflix/shared/widget/bottomNavigation.dart';

void main(){
  runApp(const MaterialApp(
    //home: HomePage()
    home: NavBar(),));
 }
 